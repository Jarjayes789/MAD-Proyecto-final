﻿namespace MAD___PF_Hotel
{
    partial class AddTypeOfRoomForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.cmboxCity = new System.Windows.Forms.ComboBox();
            this.cmboxHotel = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.cmboxTypeRoom = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.cmboxTypeBed = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtboxQuantityBed = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtboxPriceNight = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtboxAmountPeople = new System.Windows.Forms.TextBox();
            this.cmboxRoomLevel = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnAddTypeOfRoom = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtboxQuantityRooms = new System.Windows.Forms.TextBox();
            this.cmboxAmenityType = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.button1.Location = new System.Drawing.Point(694, 32);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(152, 37);
            this.button1.TabIndex = 70;
            this.button1.Text = "Search city:";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.label15.Location = new System.Drawing.Point(232, 36);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(104, 28);
            this.label15.TabIndex = 71;
            this.label15.Text = "Select city:";
            // 
            // cmboxCity
            // 
            this.cmboxCity.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.cmboxCity.FormattingEnabled = true;
            this.cmboxCity.Location = new System.Drawing.Point(342, 32);
            this.cmboxCity.Name = "cmboxCity";
            this.cmboxCity.Size = new System.Drawing.Size(331, 36);
            this.cmboxCity.TabIndex = 72;
            // 
            // cmboxHotel
            // 
            this.cmboxHotel.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.cmboxHotel.FormattingEnabled = true;
            this.cmboxHotel.Location = new System.Drawing.Point(342, 86);
            this.cmboxHotel.Name = "cmboxHotel";
            this.cmboxHotel.Size = new System.Drawing.Size(331, 36);
            this.cmboxHotel.TabIndex = 75;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.label16.Location = new System.Drawing.Point(222, 89);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(118, 28);
            this.label16.TabIndex = 74;
            this.label16.Text = "Select hotel:";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.button2.Location = new System.Drawing.Point(694, 86);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(152, 37);
            this.button2.TabIndex = 73;
            this.button2.Text = "Search hotel";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // cmboxTypeRoom
            // 
            this.cmboxTypeRoom.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.cmboxTypeRoom.FormattingEnabled = true;
            this.cmboxTypeRoom.Location = new System.Drawing.Point(354, 169);
            this.cmboxTypeRoom.Name = "cmboxTypeRoom";
            this.cmboxTypeRoom.Size = new System.Drawing.Size(331, 36);
            this.cmboxTypeRoom.TabIndex = 77;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.label17.Location = new System.Drawing.Point(215, 174);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(133, 28);
            this.label17.TabIndex = 76;
            this.label17.Text = "Type of room:";
            // 
            // cmboxTypeBed
            // 
            this.cmboxTypeBed.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.cmboxTypeBed.FormattingEnabled = true;
            this.cmboxTypeBed.Location = new System.Drawing.Point(354, 231);
            this.cmboxTypeBed.Name = "cmboxTypeBed";
            this.cmboxTypeBed.Size = new System.Drawing.Size(331, 36);
            this.cmboxTypeBed.TabIndex = 79;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.label18.Location = new System.Drawing.Point(229, 234);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(119, 28);
            this.label18.TabIndex = 78;
            this.label18.Text = "Type of bed:";
            // 
            // txtboxQuantityBed
            // 
            this.txtboxQuantityBed.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.txtboxQuantityBed.Location = new System.Drawing.Point(694, 294);
            this.txtboxQuantityBed.Name = "txtboxQuantityBed";
            this.txtboxQuantityBed.Size = new System.Drawing.Size(182, 34);
            this.txtboxQuantityBed.TabIndex = 66;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.label1.Location = new System.Drawing.Point(506, 297);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(162, 28);
            this.label1.TabIndex = 80;
            this.label1.Text = "Quantity of beds:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.label2.Location = new System.Drawing.Point(144, 351);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(143, 28);
            this.label2.TabIndex = 82;
            this.label2.Text = "Price per night:";
            // 
            // txtboxPriceNight
            // 
            this.txtboxPriceNight.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.txtboxPriceNight.Location = new System.Drawing.Point(293, 348);
            this.txtboxPriceNight.Name = "txtboxPriceNight";
            this.txtboxPriceNight.Size = new System.Drawing.Size(182, 34);
            this.txtboxPriceNight.TabIndex = 81;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.label3.Location = new System.Drawing.Point(111, 297);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(176, 28);
            this.label3.TabIndex = 84;
            this.label3.Text = "Amount of people:";
            // 
            // txtboxAmountPeople
            // 
            this.txtboxAmountPeople.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.txtboxAmountPeople.Location = new System.Drawing.Point(293, 294);
            this.txtboxAmountPeople.Name = "txtboxAmountPeople";
            this.txtboxAmountPeople.Size = new System.Drawing.Size(182, 34);
            this.txtboxAmountPeople.TabIndex = 83;
            // 
            // cmboxRoomLevel
            // 
            this.cmboxRoomLevel.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.cmboxRoomLevel.FormattingEnabled = true;
            this.cmboxRoomLevel.Location = new System.Drawing.Point(354, 408);
            this.cmboxRoomLevel.Name = "cmboxRoomLevel";
            this.cmboxRoomLevel.Size = new System.Drawing.Size(331, 36);
            this.cmboxRoomLevel.TabIndex = 86;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.label4.Location = new System.Drawing.Point(235, 411);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 28);
            this.label4.TabIndex = 85;
            this.label4.Text = "Room level:";
            // 
            // btnAddTypeOfRoom
            // 
            this.btnAddTypeOfRoom.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.btnAddTypeOfRoom.Location = new System.Drawing.Point(323, 557);
            this.btnAddTypeOfRoom.Name = "btnAddTypeOfRoom";
            this.btnAddTypeOfRoom.Size = new System.Drawing.Size(152, 37);
            this.btnAddTypeOfRoom.TabIndex = 88;
            this.btnAddTypeOfRoom.Text = " Add room";
            this.btnAddTypeOfRoom.UseVisualStyleBackColor = true;
            this.btnAddTypeOfRoom.Click += new System.EventHandler(this.btnAddTypeOfRoom_Click);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.button4.Location = new System.Drawing.Point(533, 557);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(152, 37);
            this.button4.TabIndex = 87;
            this.button4.Text = "Cancel";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.label5.Location = new System.Drawing.Point(501, 348);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(176, 28);
            this.label5.TabIndex = 90;
            this.label5.Text = "Quantity of rooms:";
            // 
            // txtboxQuantityRooms
            // 
            this.txtboxQuantityRooms.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.txtboxQuantityRooms.Location = new System.Drawing.Point(694, 345);
            this.txtboxQuantityRooms.Name = "txtboxQuantityRooms";
            this.txtboxQuantityRooms.Size = new System.Drawing.Size(182, 34);
            this.txtboxQuantityRooms.TabIndex = 89;
            // 
            // cmboxAmenityType
            // 
            this.cmboxAmenityType.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.cmboxAmenityType.FormattingEnabled = true;
            this.cmboxAmenityType.Location = new System.Drawing.Point(354, 466);
            this.cmboxAmenityType.Name = "cmboxAmenityType";
            this.cmboxAmenityType.Size = new System.Drawing.Size(331, 36);
            this.cmboxAmenityType.TabIndex = 92;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.label6.Location = new System.Drawing.Point(259, 469);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 28);
            this.label6.TabIndex = 91;
            this.label6.Text = "Amenity:";
            // 
            // AddTypeOfRoomForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(964, 606);
            this.Controls.Add(this.cmboxAmenityType);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtboxQuantityRooms);
            this.Controls.Add(this.btnAddTypeOfRoom);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.cmboxRoomLevel);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtboxAmountPeople);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtboxPriceNight);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmboxTypeBed);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.cmboxTypeRoom);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.cmboxHotel);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.cmboxCity);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtboxQuantityBed);
            this.Name = "AddTypeOfRoomForm";
            this.Text = "Add type of room";
            this.Load += new System.EventHandler(this.CRForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox cmboxCity;
        private System.Windows.Forms.ComboBox cmboxHotel;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox cmboxTypeRoom;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox cmboxTypeBed;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtboxQuantityBed;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtboxPriceNight;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtboxAmountPeople;
        private System.Windows.Forms.ComboBox cmboxRoomLevel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnAddTypeOfRoom;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtboxQuantityRooms;
        private System.Windows.Forms.ComboBox cmboxAmenityType;
        private System.Windows.Forms.Label label6;
    }
}