﻿namespace MAD___PF_Hotel
{
    partial class AddOperator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancelOp = new System.Windows.Forms.Button();
            this.btnAddOp = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.txtboxPasswordOp = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cboxTypeOfUser = new System.Windows.Forms.ComboBox();
            this.lblSuburb = new System.Windows.Forms.Label();
            this.txtboxSuburbOp = new System.Windows.Forms.TextBox();
            this.lblHouseNumber = new System.Windows.Forms.Label();
            this.txtboxHouseNoOp = new System.Windows.Forms.TextBox();
            this.lblZipCode = new System.Windows.Forms.Label();
            this.lblStreet = new System.Windows.Forms.Label();
            this.txtboxZipCodeOp = new System.Windows.Forms.TextBox();
            this.txtboxStreetOp = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtboxLastName1 = new System.Windows.Forms.TextBox();
            this.datetpDOB = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtboxCellPhoneOp = new System.Windows.Forms.TextBox();
            this.txtboxHomePhoneOp = new System.Windows.Forms.TextBox();
            this.txtboxEmailOp = new System.Windows.Forms.TextBox();
            this.txtboxPayrollNum = new System.Windows.Forms.TextBox();
            this.txtboxLastName2 = new System.Windows.Forms.TextBox();
            this.txtboxFirstNameOp = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCancelOp
            // 
            this.btnCancelOp.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelOp.Location = new System.Drawing.Point(547, 549);
            this.btnCancelOp.Name = "btnCancelOp";
            this.btnCancelOp.Size = new System.Drawing.Size(97, 36);
            this.btnCancelOp.TabIndex = 79;
            this.btnCancelOp.Text = "Cancel";
            this.btnCancelOp.UseVisualStyleBackColor = true;
            // 
            // btnAddOp
            // 
            this.btnAddOp.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddOp.Location = new System.Drawing.Point(386, 549);
            this.btnAddOp.Name = "btnAddOp";
            this.btnAddOp.Size = new System.Drawing.Size(97, 36);
            this.btnAddOp.TabIndex = 78;
            this.btnAddOp.Text = "Add";
            this.btnAddOp.UseVisualStyleBackColor = true;
            this.btnAddOp.Click += new System.EventHandler(this.btnAddOp_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.txtboxPasswordOp);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.cboxTypeOfUser);
            this.panel1.Controls.Add(this.lblSuburb);
            this.panel1.Controls.Add(this.txtboxSuburbOp);
            this.panel1.Controls.Add(this.lblHouseNumber);
            this.panel1.Controls.Add(this.txtboxHouseNoOp);
            this.panel1.Controls.Add(this.lblZipCode);
            this.panel1.Controls.Add(this.lblStreet);
            this.panel1.Controls.Add(this.txtboxZipCodeOp);
            this.panel1.Controls.Add(this.txtboxStreetOp);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.txtboxLastName1);
            this.panel1.Controls.Add(this.datetpDOB);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txtboxCellPhoneOp);
            this.panel1.Controls.Add(this.txtboxHomePhoneOp);
            this.panel1.Controls.Add(this.txtboxEmailOp);
            this.panel1.Controls.Add(this.txtboxPayrollNum);
            this.panel1.Controls.Add(this.txtboxLastName2);
            this.panel1.Controls.Add(this.txtboxFirstNameOp);
            this.panel1.Location = new System.Drawing.Point(37, 52);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(889, 475);
            this.panel1.TabIndex = 93;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(85, 338);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(97, 28);
            this.label11.TabIndex = 120;
            this.label11.Text = "Password:";
            // 
            // txtboxPasswordOp
            // 
            this.txtboxPasswordOp.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.txtboxPasswordOp.Location = new System.Drawing.Point(197, 335);
            this.txtboxPasswordOp.Name = "txtboxPasswordOp";
            this.txtboxPasswordOp.Size = new System.Drawing.Size(245, 34);
            this.txtboxPasswordOp.TabIndex = 119;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(484, 336);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(122, 28);
            this.label7.TabIndex = 118;
            this.label7.Text = "Type of user:";
            // 
            // cboxTypeOfUser
            // 
            this.cboxTypeOfUser.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboxTypeOfUser.FormattingEnabled = true;
            this.cboxTypeOfUser.Location = new System.Drawing.Point(620, 333);
            this.cboxTypeOfUser.Name = "cboxTypeOfUser";
            this.cboxTypeOfUser.Size = new System.Drawing.Size(245, 36);
            this.cboxTypeOfUser.Sorted = true;
            this.cboxTypeOfUser.TabIndex = 117;
            this.cboxTypeOfUser.SelectedIndexChanged += new System.EventHandler(this.cboxTypeOfUser_SelectedIndexChanged);
            // 
            // lblSuburb
            // 
            this.lblSuburb.AutoSize = true;
            this.lblSuburb.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.lblSuburb.Location = new System.Drawing.Point(526, 150);
            this.lblSuburb.Name = "lblSuburb";
            this.lblSuburb.Size = new System.Drawing.Size(80, 28);
            this.lblSuburb.TabIndex = 116;
            this.lblSuburb.Text = "Suburb:";
            // 
            // txtboxSuburbOp
            // 
            this.txtboxSuburbOp.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.txtboxSuburbOp.Location = new System.Drawing.Point(620, 146);
            this.txtboxSuburbOp.Name = "txtboxSuburbOp";
            this.txtboxSuburbOp.Size = new System.Drawing.Size(245, 34);
            this.txtboxSuburbOp.TabIndex = 115;
            // 
            // lblHouseNumber
            // 
            this.lblHouseNumber.AutoSize = true;
            this.lblHouseNumber.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.lblHouseNumber.Location = new System.Drawing.Point(461, 103);
            this.lblHouseNumber.Name = "lblHouseNumber";
            this.lblHouseNumber.Size = new System.Drawing.Size(145, 28);
            this.lblHouseNumber.TabIndex = 114;
            this.lblHouseNumber.Text = "House number:";
            // 
            // txtboxHouseNoOp
            // 
            this.txtboxHouseNoOp.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.txtboxHouseNoOp.Location = new System.Drawing.Point(620, 99);
            this.txtboxHouseNoOp.Name = "txtboxHouseNoOp";
            this.txtboxHouseNoOp.Size = new System.Drawing.Size(245, 34);
            this.txtboxHouseNoOp.TabIndex = 113;
            // 
            // lblZipCode
            // 
            this.lblZipCode.AutoSize = true;
            this.lblZipCode.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.lblZipCode.Location = new System.Drawing.Point(511, 197);
            this.lblZipCode.Name = "lblZipCode";
            this.lblZipCode.Size = new System.Drawing.Size(95, 28);
            this.lblZipCode.TabIndex = 112;
            this.lblZipCode.Text = "Zip Code:";
            // 
            // lblStreet
            // 
            this.lblStreet.AutoSize = true;
            this.lblStreet.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.lblStreet.Location = new System.Drawing.Point(486, 58);
            this.lblStreet.Name = "lblStreet";
            this.lblStreet.Size = new System.Drawing.Size(120, 28);
            this.lblStreet.TabIndex = 111;
            this.lblStreet.Text = "Street name:";
            // 
            // txtboxZipCodeOp
            // 
            this.txtboxZipCodeOp.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.txtboxZipCodeOp.Location = new System.Drawing.Point(620, 193);
            this.txtboxZipCodeOp.Name = "txtboxZipCodeOp";
            this.txtboxZipCodeOp.Size = new System.Drawing.Size(245, 34);
            this.txtboxZipCodeOp.TabIndex = 110;
            // 
            // txtboxStreetOp
            // 
            this.txtboxStreetOp.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.txtboxStreetOp.Location = new System.Drawing.Point(620, 55);
            this.txtboxStreetOp.Name = "txtboxStreetOp";
            this.txtboxStreetOp.Size = new System.Drawing.Size(245, 34);
            this.txtboxStreetOp.TabIndex = 109;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(79, 103);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(103, 28);
            this.label10.TabIndex = 108;
            this.label10.Text = "Last name:";
            // 
            // txtboxLastName1
            // 
            this.txtboxLastName1.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.txtboxLastName1.Location = new System.Drawing.Point(197, 100);
            this.txtboxLastName1.Name = "txtboxLastName1";
            this.txtboxLastName1.Size = new System.Drawing.Size(245, 34);
            this.txtboxLastName1.TabIndex = 107;
            // 
            // datetpDOB
            // 
            this.datetpDOB.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.datetpDOB.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datetpDOB.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datetpDOB.Location = new System.Drawing.Point(197, 286);
            this.datetpDOB.Name = "datetpDOB";
            this.datetpDOB.Size = new System.Drawing.Size(245, 34);
            this.datetpDOB.TabIndex = 106;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(54, 289);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(128, 28);
            this.label8.TabIndex = 105;
            this.label8.Text = "Date of birth:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(503, 290);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(104, 28);
            this.label6.TabIndex = 104;
            this.label6.Text = "Cellphone:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(477, 242);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(130, 28);
            this.label5.TabIndex = 103;
            this.label5.Text = "Home phone:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(119, 196);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 28);
            this.label4.TabIndex = 102;
            this.label4.Text = "Email:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(29, 242);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(153, 28);
            this.label3.TabIndex = 101;
            this.label3.Text = "Payroll Number:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(13, 149);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(169, 28);
            this.label2.TabIndex = 100;
            this.label2.Text = "Second last name:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(56, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 28);
            this.label1.TabIndex = 99;
            this.label1.Text = "First name(s):";
            // 
            // txtboxCellPhoneOp
            // 
            this.txtboxCellPhoneOp.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxCellPhoneOp.Location = new System.Drawing.Point(620, 286);
            this.txtboxCellPhoneOp.Name = "txtboxCellPhoneOp";
            this.txtboxCellPhoneOp.Size = new System.Drawing.Size(245, 34);
            this.txtboxCellPhoneOp.TabIndex = 98;
            // 
            // txtboxHomePhoneOp
            // 
            this.txtboxHomePhoneOp.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxHomePhoneOp.Location = new System.Drawing.Point(620, 238);
            this.txtboxHomePhoneOp.Name = "txtboxHomePhoneOp";
            this.txtboxHomePhoneOp.Size = new System.Drawing.Size(245, 34);
            this.txtboxHomePhoneOp.TabIndex = 97;
            // 
            // txtboxEmailOp
            // 
            this.txtboxEmailOp.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.txtboxEmailOp.Location = new System.Drawing.Point(197, 193);
            this.txtboxEmailOp.Name = "txtboxEmailOp";
            this.txtboxEmailOp.Size = new System.Drawing.Size(245, 34);
            this.txtboxEmailOp.TabIndex = 96;
            // 
            // txtboxPayrollNum
            // 
            this.txtboxPayrollNum.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.txtboxPayrollNum.Location = new System.Drawing.Point(197, 239);
            this.txtboxPayrollNum.Name = "txtboxPayrollNum";
            this.txtboxPayrollNum.Size = new System.Drawing.Size(245, 34);
            this.txtboxPayrollNum.TabIndex = 95;
            // 
            // txtboxLastName2
            // 
            this.txtboxLastName2.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.txtboxLastName2.Location = new System.Drawing.Point(197, 146);
            this.txtboxLastName2.Name = "txtboxLastName2";
            this.txtboxLastName2.Size = new System.Drawing.Size(245, 34);
            this.txtboxLastName2.TabIndex = 94;
            // 
            // txtboxFirstNameOp
            // 
            this.txtboxFirstNameOp.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.txtboxFirstNameOp.Location = new System.Drawing.Point(197, 55);
            this.txtboxFirstNameOp.Name = "txtboxFirstNameOp";
            this.txtboxFirstNameOp.Size = new System.Drawing.Size(245, 34);
            this.txtboxFirstNameOp.TabIndex = 93;
            this.txtboxFirstNameOp.TextChanged += new System.EventHandler(this.txtboxFirstNameOp_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Nirmala UI", 12F);
            this.label9.Location = new System.Drawing.Point(444, 13);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(131, 28);
            this.label9.TabIndex = 94;
            this.label9.Text = "Add operator";
            // 
            // AddOperator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(964, 606);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnCancelOp);
            this.Controls.Add(this.btnAddOp);
            this.Name = "AddOperator";
            this.Text = "Add Operator";
            this.Load += new System.EventHandler(this.AddOperator_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnCancelOp;
        private System.Windows.Forms.Button btnAddOp;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cboxTypeOfUser;
        private System.Windows.Forms.Label lblSuburb;
        private System.Windows.Forms.TextBox txtboxSuburbOp;
        private System.Windows.Forms.Label lblHouseNumber;
        private System.Windows.Forms.TextBox txtboxHouseNoOp;
        private System.Windows.Forms.Label lblZipCode;
        private System.Windows.Forms.Label lblStreet;
        private System.Windows.Forms.TextBox txtboxZipCodeOp;
        private System.Windows.Forms.TextBox txtboxStreetOp;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtboxLastName1;
        private System.Windows.Forms.DateTimePicker datetpDOB;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtboxCellPhoneOp;
        private System.Windows.Forms.TextBox txtboxHomePhoneOp;
        private System.Windows.Forms.TextBox txtboxEmailOp;
        private System.Windows.Forms.TextBox txtboxPayrollNum;
        private System.Windows.Forms.TextBox txtboxLastName2;
        private System.Windows.Forms.TextBox txtboxFirstNameOp;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtboxPasswordOp;
    }
}