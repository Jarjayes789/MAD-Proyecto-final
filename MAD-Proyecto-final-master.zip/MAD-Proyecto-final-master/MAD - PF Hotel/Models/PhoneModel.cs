﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MAD___PF_Hotel.Models
{
    internal class PhoneModel
    {
        //public int Id_Phone { get; set; }
        public string Phone_Number { get; set; }
        public string Cellphone_Number { get; set; }
    }
}
